
document.getElementById("appendButton").addEventListener("click", function () {
  appendToDisplay(this.value);
});

document.getElementById("clearButton").addEventListener("click", clearDisplay);

document.getElementById("calculateButton").addEventListener("click", calculate);

function appendToDisplay(value) {
  document.getElementById("display").value += value;
}

function clearDisplay() {
  document.getElementById("display").value = "";
}

function calculate() {
  let expression = document.getElementById("display").value;
  let result;
  try {
    result = eval(expression);
    if (isNaN(result) || !isFinite(result)) {
      throw "Invalid expression";
    }
    document.getElementById("display").value = result;
  } catch (error) {
    document.getElementById("display").value = "Division by zero error";
  }
}
document.body.style.zoom = "100%";
