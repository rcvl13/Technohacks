document.getElementById('registrationForm').addEventListener('submit', function(event) {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    let isValid = true;
  
    // Username validation
    const usernameError = document.getElementById('usernameError');
    if (username.trim() === '') {
      usernameError.textContent = 'Username is required';
      isValid = false;
    } else {
      usernameError.textContent = '';
    }
  
    // Email validation
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      emailError.textContent = 'Invalid email address';
      isValid = false;
    } else {
      emailError.textContent = '';
    }
  
    // Password validation
    const passwordError = document.getElementById('passwordError');
    if (password.length < 6) {
      passwordError.textContent = 'Password must be at least 6 characters long';
      isValid = false;
    } else {
      passwordError.textContent = '';
    }
  
    // Confirm password validation
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    if (password !== confirmPassword) {
      confirmPasswordError.textContent = 'Passwords do not match';
      isValid = false;
    } else {
      confirmPasswordError.textContent = '';
    }
  
    if (!isValid) {
      event.preventDefault(); // Prevent form submission if there are validation errors
    }
  });
  